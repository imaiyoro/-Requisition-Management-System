CREATE TABLE departments (
  dept_id INT AUTO_INCREMENT PRIMARY KEY,
  dept_name VARCHAR(100) NOT NULL
);

CREATE TABLE users (
  user_id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(100) NOT NULL,
  password VARCHAR(100) NOT NULL,
  role ENUM('requester', 'approver', 'admin') NOT NULL,
  dept_id INT,
  FOREIGN KEY (dept_id) REFERENCES departments(dept_id)
);

CREATE TABLE requisitions (
  req_id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT,
  dept_id INT,
  item_name VARCHAR(255),
  quantity INT,
  reason TEXT,
  status ENUM('Pending', 'Approved', 'Rejected', 'Ordered') DEFAULT 'Pending',
  date_created DATETIME,
  FOREIGN KEY (user_id) REFERENCES users(user_id),
  FOREIGN KEY (dept_id) REFERENCES departments(dept_id)
);