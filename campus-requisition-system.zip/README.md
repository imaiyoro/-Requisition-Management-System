# Campus Requisition System

This is a simple web-based system for submitting and managing requisition requests on a campus.

## Technologies
- Node.js + Express
- MySQL
- HTML, JS (Vanilla)

## How to Run

1. **Setup the Database**
   - Create a MySQL database named `requisition_db`
   - Run the SQL script in `database/schema.sql`

2. **Backend Setup**
   ```bash
   cd backend
   npm install express mysql2 cors
   node server.js
   ```

3. **Frontend**
   - Open `frontend/requisition_form.html` in your browser
   - Submit a requisition

## Status
MVP functional — more features like login/auth and approval stages can be added.