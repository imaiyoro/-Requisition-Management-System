const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');
const app = express();
const db = require('./db');

app.use(cors());
app.use(express.json());

app.post('/requisitions', (req, res) => {
  const { user_id, dept_id, item_name, quantity, reason } = req.body;
  const sql = 'INSERT INTO requisitions (user_id, dept_id, item_name, quantity, reason, status, date_created) VALUES (?, ?, ?, ?, ?, "Pending", NOW())';
  db.query(sql, [user_id, dept_id, item_name, quantity, reason], (err, result) => {
    if (err) {
      console.error('Error inserting requisition:', err);
      return res.status(500).json({ message: 'Failed to submit requisition' });
    }
    res.json({ message: 'Requisition submitted successfully' });
  });
});

const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});